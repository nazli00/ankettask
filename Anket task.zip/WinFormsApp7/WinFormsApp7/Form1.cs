using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace WinFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private List<string>? surveyData = new List<string>();

        private void addbtn_Click(object sender, EventArgs e)
        {
            string info = name.Text;
            surveyData!.Add(info);

            list_of_names.Items.Add(info);
        }

        private void loadbtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(filename.Text) && File.Exists(filename.Text + ".json"))
            {
                string json = File.ReadAllText(filename.Text + ".json");
                surveyData = JsonConvert.DeserializeObject<List<string>>(json);
                list_of_names.Items.Clear();
                list_of_names.Items.AddRange(surveyData!.ToArray());
            }
            else
            {
                MessageBox.Show("File not found.Please first save file");
            }
        }
        private void savebtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(filename.Text))
            {
                string userName = name.Text;

                var users = new Dictionary<string, UserData>();

                if (File.Exists(filename.Text + ".json"))
                {
                    string jsonText = File.ReadAllText(filename.Text + ".json");
                    users = JsonConvert.DeserializeObject<Dictionary<string, UserData>>(jsonText);
                }

                var user = new UserData
                {
                    Name = userName,
                    Surname = surname.Text,
                    Email = email.Text,
                    PhoneNumber = phone_num.Text,
                    BirthDay = birthd.Text
                };

                users![userName] = user;
                string json = JsonConvert.SerializeObject(users);

                File.WriteAllText(filename.Text + ".json", json);

                MessageBox.Show("User data saved!");
            }
            else
            {
                MessageBox.Show("Please enter a filename.");
            }
        }
        private void filename_TextChanged(object sender, EventArgs e)
        {
            if (filename.Text == "")
            {
                label.Visible = true;
            }
            else { label.Visible = false; }
        }
        private void listbox_Click(object sender, EventArgs e)
        {
            //listbox-daki elementleri resetlemek ucundur.
            list_of_names.Items.Clear();
            surveyData = new List<string>();

        }
        public class UserData
        {
            public string? Name { get; set; }
            public string? Surname { get; set; }
            public string? Email { get; set; }
            public string? PhoneNumber { get; set; }
            public string? BirthDay { get; set; }
        }
    }
}
