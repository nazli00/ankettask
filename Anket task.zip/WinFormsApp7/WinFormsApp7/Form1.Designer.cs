﻿namespace WinFormsApp7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Anket = new GroupBox();
            addbtn = new Button();
            surname = new TextBox();
            phone_num = new TextBox();
            birthd = new TextBox();
            email = new TextBox();
            name = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            list_of_names = new ListBox();
            panel1 = new Panel();
            listbox = new Label();
            loadbtn = new Button();
            savebtn = new Button();
            filename = new TextBox();
            label = new Label();
            Anket.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // Anket
            // 
            Anket.Controls.Add(addbtn);
            Anket.Controls.Add(surname);
            Anket.Controls.Add(phone_num);
            Anket.Controls.Add(birthd);
            Anket.Controls.Add(email);
            Anket.Controls.Add(name);
            Anket.Controls.Add(label5);
            Anket.Controls.Add(label4);
            Anket.Controls.Add(label3);
            Anket.Controls.Add(label2);
            Anket.Controls.Add(label1);
            Anket.Location = new Point(12, 12);
            Anket.Name = "Anket";
            Anket.Size = new Size(455, 420);
            Anket.TabIndex = 0;
            Anket.TabStop = false;
            Anket.Text = "Anket";
            // 
            // addbtn
            // 
            addbtn.Location = new Point(284, 322);
            addbtn.Name = "addbtn";
            addbtn.Size = new Size(138, 39);
            addbtn.TabIndex = 11;
            addbtn.Text = "Add";
            addbtn.UseVisualStyleBackColor = true;
            addbtn.Click += addbtn_Click;
            // 
            // surname
            // 
            surname.Location = new Point(185, 105);
            surname.Name = "surname";
            surname.Size = new Size(150, 31);
            surname.TabIndex = 9;
            // 
            // phone_num
            // 
            phone_num.Location = new Point(185, 187);
            phone_num.Name = "phone_num";
            phone_num.Size = new Size(150, 31);
            phone_num.TabIndex = 8;
            // 
            // birthd
            // 
            birthd.Location = new Point(185, 228);
            birthd.Name = "birthd";
            birthd.Size = new Size(150, 31);
            birthd.TabIndex = 7;
            // 
            // email
            // 
            email.Location = new Point(185, 147);
            email.Name = "email";
            email.Size = new Size(150, 31);
            email.TabIndex = 6;
            // 
            // name
            // 
            name.Location = new Point(185, 60);
            name.Name = "name";
            name.Size = new Size(150, 31);
            name.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(29, 228);
            label5.Name = "label5";
            label5.Size = new Size(86, 25);
            label5.TabIndex = 4;
            label5.Text = "Birthday :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(29, 187);
            label4.Name = "label4";
            label4.Size = new Size(141, 25);
            label4.TabIndex = 3;
            label4.Text = "Phone Number :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 147);
            label3.Name = "label3";
            label3.Size = new Size(63, 25);
            label3.TabIndex = 2;
            label3.Text = "Email :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 105);
            label2.Name = "label2";
            label2.Size = new Size(91, 25);
            label2.TabIndex = 1;
            label2.Text = "Surname :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 60);
            label1.Name = "label1";
            label1.Size = new Size(68, 25);
            label1.TabIndex = 0;
            label1.Text = "Name :";
            // 
            // list_of_names
            // 
            list_of_names.BackColor = SystemColors.Menu;
            list_of_names.BorderStyle = BorderStyle.FixedSingle;
            list_of_names.FormattingEnabled = true;
            list_of_names.ItemHeight = 25;
            list_of_names.Location = new Point(0, 55);
            list_of_names.Name = "list_of_names";
            list_of_names.Size = new Size(303, 227);
            list_of_names.TabIndex = 12;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(listbox);
            panel1.Controls.Add(list_of_names);
            panel1.Location = new Point(484, 23);
            panel1.Name = "panel1";
            panel1.Size = new Size(304, 284);
            panel1.TabIndex = 1;
            // 
            // listbox
            // 
            listbox.AutoSize = true;
            listbox.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            listbox.Location = new Point(116, 17);
            listbox.Name = "listbox";
            listbox.Size = new Size(81, 28);
            listbox.TabIndex = 13;
            listbox.Text = "ListBox";
            listbox.Click += listbox_Click;
            // 
            // loadbtn
            // 
            loadbtn.Location = new Point(485, 380);
            loadbtn.Name = "loadbtn";
            loadbtn.Size = new Size(125, 34);
            loadbtn.TabIndex = 2;
            loadbtn.Text = "Load";
            loadbtn.UseVisualStyleBackColor = true;
            loadbtn.Click += loadbtn_Click;
            // 
            // savebtn
            // 
            savebtn.Location = new Point(633, 380);
            savebtn.Name = "savebtn";
            savebtn.Size = new Size(125, 34);
            savebtn.TabIndex = 3;
            savebtn.Text = "Save";
            savebtn.UseVisualStyleBackColor = true;
            savebtn.Click += savebtn_Click;
            // 
            // filename
            // 
            filename.BackColor = Color.White;
            filename.Cursor = Cursors.IBeam;
            filename.ForeColor = Color.Black;
            filename.Location = new Point(485, 331);
            filename.Name = "filename";
            filename.Size = new Size(303, 31);
            filename.TabIndex = 4;
            filename.TextChanged += filename_TextChanged;
            // 
            // label
            // 
            label.AutoSize = true;
            label.BackColor = SystemColors.ButtonHighlight;
            label.ForeColor = Color.DarkGray;
            label.Location = new Point(485, 334);
            label.Name = "label";
            label.Size = new Size(87, 25);
            label.TabIndex = 5;
            label.Text = "File name";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label);
            Controls.Add(filename);
            Controls.Add(savebtn);
            Controls.Add(loadbtn);
            Controls.Add(panel1);
            Controls.Add(Anket);
            Name = "Form1";
            Text = "Form1";
            Anket.ResumeLayout(false);
            Anket.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox Anket;
        private TextBox phone_num;
        private TextBox birthd;
        private TextBox email;
        private TextBox name;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox surname;
        private Button addbtn;
        private ListBox list_of_names;
        private Panel panel1;
        private Label listbox;
        private Button loadbtn;
        private Button savebtn;
        private TextBox filename;
        private Label label;
    }
}